WIREFRAME MOBILE — SISTEM INFORMASI PEMINJAMAN BUKU ONLINE

Isi folder:
00_Wireframe_Lengkap.png
01_Beranda_Pengunjung.png
02_Login.png
03_Registrasi.png
04_Lupa_Kata_Sandi.png
05_Reset_Kata_Sandi.png
06_Katalog_Buku.png
07_Detail_Buku.png
08_Pilih_Buku.png
09_Dashboard_Anggota.png
10_Form_Pengajuan.png
11_Konfirmasi_Pengajuan.png
12_Pengajuan_Berhasil.png
13_Peminjaman_Saya.png
14_Detail_Tracking.png
15_Riwayat_Peminjaman.png
16_Profil_Anggota.png
17_Alur_Utama_User_Flow.png
18_Status_Peminjaman_BRD_PRD.png

Acuan:
- BRD Sistem Informasi Peminjaman Buku Online Mobile
- PRD Sistem Informasi Peminjaman Buku Online Mobile
- Platform: Android / Flutter
- Aktor mobile: Pengunjung dan Anggota
